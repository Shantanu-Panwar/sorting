#include<bits/stdc++.h>
using namespace std; int
main() {
int t;
cin >>t;
while (t--)
{
int n;
cin >>n;
int a[n];
for (int i = 0; i < n;i++)
cin >> a[i];
int sh = 0, comp = 0;
for (int i = 0; i < n- 1; i++)
{
int m = a[i], pos;
for (int k = i + 1; k < n; k++) {
comp++;
if (a[k] < m) {
m =a[k];
pos = k;
}
}
sh++;
a[pos] =a[i];
a[i] =m;
}
for (int i = 0; i < n;i++) 
cout << a[i]<< " ";
cout << endl;
cout << "comparisons = " << comp <<endl; cout << "swaps = " << sh << endl;
}
return 0;
}